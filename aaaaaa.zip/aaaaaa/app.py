from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

def db():
    return sqlite3.connect("main.db")

# =========================
# 🔹 LISTAR PRODUTOS
# =========================
@app.route("/gifts")
def gifts():
    conn = db()
    cur = conn.cursor()

    data = cur.execute("""
        SELECT gp.id, gp.name, COUNT(gc.id)
        FROM gift_products gp
        LEFT JOIN gift_codes gc
        ON gp.id = gc.product_id AND gc.used = 0
        GROUP BY gp.id
    """).fetchall()

    return jsonify([
        {"id": i[0], "name": i[1], "stock": i[2]}
        for i in data
    ])

# =========================
# 🔹 SALDOS
# =========================
@app.route("/gift/<int:gid>")
def gift(gid):
    conn = db()
    cur = conn.cursor()

    rows = cur.execute("""
        SELECT gc.saldo, gp.price, COUNT(gc.id)
        FROM gift_codes gc
        LEFT JOIN gift_prices gp
        ON gp.product_id = gc.product_id AND gp.saldo = gc.saldo
        WHERE gc.product_id = ? AND gc.used = 0
        GROUP BY gc.saldo
    """, (gid,)).fetchall()

    return jsonify([
        {"saldo": r[0], "price": r[1], "stock": r[2]}
        for r in rows
    ])

# =========================
# 🔹 USUÁRIO
# =========================
@app.route("/user/<int:user_id>")
def user(user_id):
    conn = db()
    cur = conn.cursor()

    u = cur.execute(
        "SELECT balance FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()

    return jsonify({"balance": u[0] if u else 0})

# =========================
# 🔹 COMPRA
# =========================
@app.route("/buy", methods=["POST"])
def buy():
    data = request.json
    user_id = data["user_id"]
    gid = data["gid"]
    saldo = data["saldo"]
    qtd = data["qtd"]

    conn = db()
    cur = conn.cursor()

    try:
        cur.execute("BEGIN")

        price = cur.execute(
            "SELECT price FROM gift_prices WHERE product_id = ? AND saldo = ?",
            (gid, saldo)
        ).fetchone()[0]

        total = price * qtd

        balance = cur.execute(
            "SELECT balance FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()[0]

        if balance < total:
            return jsonify({"error": "Saldo insuficiente"})

        codes = cur.execute("""
            SELECT id, code FROM gift_codes 
            WHERE product_id = ? AND saldo = ? AND used = 0 LIMIT ?
        """, (gid, saldo, qtd)).fetchall()

        if len(codes) < qtd:
            return jsonify({"error": "Estoque insuficiente"})

        code_list = []

        for cid, code in codes:
            cur.execute("UPDATE gift_codes SET used = 1 WHERE id = ?", (cid,))
            code_list.append(code)

        cur.execute(
            "UPDATE users SET balance = balance - ? WHERE id = ?",
            (total, user_id)
        )

        for _ in range(qtd):
            cur.execute(
                "INSERT INTO gift_solds (user_id, product_id, saldo, price) VALUES (?, ?, ?, ?)",
                (user_id, gid, saldo, price)
            )

        conn.commit()

        return jsonify({
            "success": True,
            "codes": code_list,
            "total": total
        })

    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)})

app.run(host="0.0.0.0", port=10000)